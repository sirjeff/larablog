<div class="footer-spacer"></div>
<div class="footsm container-fluid hero-cover">
      <div class="jumbotron">
           <p class="text-center">{{ \App\Config::where(['name' => 'copyright'])->first()->value }}</p>
      </div>
</div>

