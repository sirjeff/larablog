<h3>New Message via your contact form</h3>
<p>Sent from {{ $email }}</p>
<hr>
<pre>{{ $bodyMessage }}</pre>
<hr>

