@extends('main')
@section('title','Administration')

@section('content')
    <div class="row">
        <div class="col-md-9">
            <h1>Administration</h1>
        </div>
        <div class="col-md-3">

        </div>
        <div class="col-md-12">
            <hr>
        </div>
        <hr>
     </div>

    <div class="row">
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <tr>
                        <th></th>
                        <th>#</th>
                        <th>Title</th>
                        <th>Post</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                </tbody>
            </table>
            <div class="text-center">
                <h5></h5>
            </div>
        </div>
    </div>

@endsection