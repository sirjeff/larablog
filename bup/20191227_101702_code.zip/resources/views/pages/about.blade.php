@extends('main')
@section('title','About')

@section('content')


 
<div class="row">
    <div class="col-md-6">
        <div class="post_image">
           <img src="{{ '/images/full/' . $about_post->image }}" alt="{{$about_post->image}}" width="100%">
         </div>
    </div>

    <div class="col-md-6 post_deets">
        <h1>{{ $about_post->title }}</h1>
        <hr>
        <dl class="dl-horizontal">
            <dt>Author:</dt>
            <dd>{{ $about_post->user->name }}</dd>
        </dl>
        <dl class="dl-horizontal">
            <dt>Published in:</dt>
            <dd>{{ $about_post->category->name }}</dd>
        </dl>
        <dl class="dl-horizontal">
            <dt>Published date:</dt>
            <dd>{{ date('M j, Y h:ia', strtotime($about_post->created_at)) }}</dd>
        </dl>
        <dl class="dl-horizontal">
            <dt>Tags:</dt>
            <dd>@foreach($about_post->tags as $tag)<span class="label label-default">{{ $tag->name }}</span>@endforeach</dd>
        </dl>
    </div>
</div>

<div class="row post_body">
    <div class="col-md-12">
        <p>{!! $about_post->body !!}</p>
    </div>
</div>


@endsection