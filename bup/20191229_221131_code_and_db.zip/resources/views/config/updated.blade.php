@extends('main')
@section('title','Updated')


@section('content')
    <div class="row">
        <h1>Config</h1>
        <hr>
       
    </div>
@endsection

