@extends('main')
@section('title','Configuration')

@section('content')
<div class="row">
 <div class="col-md-12">
  <h1>Configuration</h1>
  <p>Modify some of the page content and settings here.</p>
  <hr>
 </div>
</div>

<div class="row">
 <div class="col-md-12">
  <table class="table">
   <thead>
    <tr>
     <th>ID</th>
     <th>Name</th>
     <th>Value</th>
     <th>Description</th>
    </tr>
   </thead>
   <tbody>
    @foreach ($configs as $config)
    <tr>
     <td>{{ $config->id }}</td>
     <td>{{ $config->name }}</td>
     <td>{{ $config->value }}</td>
     <td>{{ $config->description }}</td>
    </tr>
    @endforeach
   </tbody>
  </table>
  <div class="text-center">
   <h5>Update notification goes here.... (WiP)</h5>
  </div>
 </div>
</div>

@endsection