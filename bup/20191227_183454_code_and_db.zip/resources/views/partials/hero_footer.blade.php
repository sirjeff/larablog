<div class="footer-spacer"></div>
<div class="footsm container-fluid hero-cover">
      <div class="jumbotron">
           <p class="text-center">&copy; Copyright 2019 - All rights reserved</p>
      </div>
</div>

